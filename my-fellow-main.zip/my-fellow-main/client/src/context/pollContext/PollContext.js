import { createContext } from "react"

export const PollContext = createContext()
